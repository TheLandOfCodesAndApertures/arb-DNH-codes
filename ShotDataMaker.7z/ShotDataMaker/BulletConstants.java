public class BulletConstants {
	public static int	BLEND_ALPHA=0;
	public static int	BLEND_ADD_RGB=1;
	public static int	BLEND_ADD_ARGB=2;
	public static String[] BLENDS_LIST={
						"ALPHA",
						"ADD_RGB",
						"ADD_ARGB"
						};
	public BulletConstants(){}
}
